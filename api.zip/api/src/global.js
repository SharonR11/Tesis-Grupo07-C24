// module.exports = {
//     secret: 'mysecrettext',
//     port: 4000
// }
export const PORT =  4000;
export const SECRET = "yoursecretkey";
export const ADMIN_EMAIL = "sharon@abc.com";
export const ADMIN_USERNAME = "sharon";
export const ADMIN_PASSWORD = "sharon";